# Rebuild the corrected standalone archive from source; no stale run data is used.
set here [file dirname [file normalize [info script]]]
set src [file join $here project_2026_11_02.srcs sources_1]
set xdc [file join $here project_2026_11_02.srcs constrs_1 new Basys3_Master.xdc]
create_project project_2026_11_02_triangle_fix [file join $here vivado_rebuilt] -part xc7a35tcpg236-1 -force
set_property target_language Verilog [current_project]
add_files -norecurse -fileset sources_1 [glob [file join $src new *.v]]
add_files -norecurse -fileset sources_1 [glob [file join $src imports practice_project *.v]]
add_files -norecurse -fileset constrs_1 $xdc
add_files -norecurse -fileset sim_1 [file join $here project_2026_11_02.srcs sim_1 new triangle_tb.v]
set_property top My_Top_Module [get_filesets sources_1]
set_property top triangle_tb [get_filesets sim_1]
update_compile_order -fileset sources_1
puts "Project created at [file join $here vivado_rebuilt project_2026_11_02_triangle_fix.xpr]"
