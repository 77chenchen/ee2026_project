Triangle timing source fix for Hanna's 2026-11-02 project.

right_angle_triangle.v now computes the integer square root over eight clock
cycles instead of cascading eight binary-search iterations in one cycle.
The module's ports, controls, and triangle_renderer.v are unchanged.
The XDC also braces seg[7] so Tcl reads the port name literally.
The calculator's selected_number declaration is moved before its first use;
no calculator behavior was changed.

This is a source-only package. The original bitstream and routed timing report
were excluded because they describe the unmodified design (WNS -70.111 ns).
No new Vivado routed timing result or bitstream is claimed.

In Vivado 2025.2 Tcl Console on Windows:
  source {C:/path/to/project_2026_11_02/build_triangle_fix.tcl}
  launch_runs synth_1 -jobs 4
  wait_on_run synth_1
  launch_runs impl_1 -to_step write_bitstream -jobs 4
  wait_on_run impl_1
  open_run impl_1
  report_timing_summary -file {C:/path/to/triangle_fix_timing.rpt}

Only use the newly generated .bit after checking WNS, WHS, WPWS and testing
all modes on the board. The original 2026-11-02 ZIP remains unchanged.
