`timescale 1ns / 1ps

module calculator(input CLOCK,
                  input btnU, btnD, btnL, btnR, btnC,
                  input [10:0] sw,
                  input SW13, SW14, SW15,
                  input [12:0] pixel_index,
                  output wire [15:0] oled_data,
                  output reg [3:0] an,
                  output reg [7:0] seg
                  );
                      
    wire [6:0] x;
    wire [5:0] y;
    
    assign x = pixel_index % 96;
    assign y = pixel_index / 96;
    
    localparam BLACK  = 16'h0000;
    localparam ORANGE = 16'hFF60;
    localparam GREEN  = 16'h07E0;
           
     // States:
    localparam FIRST_NUMBER     = 2'b00;
    localparam CHOOSE_OPERATION = 2'b01;
    localparam SECOND_NUMBER    = 2'b10;
    localparam SHOW_RESULT      = 2'b11;
    reg [1:0] state = FIRST_NUMBER;

    // Calculations:

    // Switch input format: sw[7] = sign, sw[6:0] = magnitude.
    wire signed [7:0] switch_value = sw[7] ? -$signed({1'b0,sw[6:0]}) : $signed({1'b0,sw[6:0]});
    wire signed [7:0] operand_A, operand_B;
    wire numbers_ready;
    wire capture_A = (state == FIRST_NUMBER) && btnC;
    wire capture_B = (state == SECOND_NUMBER) && btnC;
    wire new_calculation = (state == SHOW_RESULT) && SW14;
    
    // Switches to binary:
    switch_to_binary number_storage(.clk(CLOCK),
                                    .reset(new_calculation),
                                    .sw(sw),
                                    .save_first(capture_A),
                                    .save_second(capture_B),
                                    .saved_number_1(operand_A),
                                    .saved_number_2(operand_B),
                                    .ready(numbers_ready));
        
    // Operation choices
    reg [1:0] operation;
    
    localparam ADD = 2'b00;
    localparam SUB = 2'b01;
    localparam MUL = 2'b10;
    localparam DIV = 2'b11;
    
    reg operation_selected = 0;

    // Result not larger than 8 bits
    reg signed [15:0] result = 0;
    
    wire signed [15:0] calculated_result =
        (operation == ADD) ? ($signed(operand_A) + $signed(switch_value)) :
        (operation == SUB) ? ($signed(operand_A) - $signed(switch_value)) :
        (operation == MUL) ? ($signed(operand_A) * $signed(switch_value)) :
        (switch_value != 0) ? ($signed(operand_A) / $signed(switch_value)) : 16'sd0;
    
    // Validate at second-number confirmation, using the live switch value.
    wire invalid_now;
    check_invalid validator (.saved_number_2(switch_value),
                             .ready(operation_selected && state == SECOND_NUMBER),
                             .operation(operation), 
                             .invalid(invalid_now)
    );
    
    reg invalid_result = 0;
    
    // Check for overflow:
    wire overflow;
    check_overflow overflow_checker (.result(result), 
                                     .overflow(overflow));
   
    //OLED graphics for owerflow
    wire [15:0] overflow_pixel;
    owerflow_renderer overflow_screen(.pixel_index(pixel_index),
                                      .overflow(overflow),
                                      .pixel_data(overflow_pixel));
    
    // Save history:
    reg history_saved = 0;
    
    wire save_history = (state == SHOW_RESULT) &&
                        !invalid_result &&
                        !overflow &&
                        !history_saved;
    
    wire [1:0] history_count;
    
    wire signed [7:0] history_0, history_1, history_2;
    
    wire signed [7:0] history_a0, history_a1, history_a2;
    wire signed [7:0] history_b0, history_b1, history_b2;
    
    wire [1:0] history_op0, history_op1, history_op2;
    

    calculation_history history_module (.clk(CLOCK), 
                                        .reset(1'b0),
                                        .save(save_history), 
                                        
                                        .operand_a(operand_A),
                                        .operand_b(operand_B),
                                        .operation(operation),
                                        .result(result),
                                        
                                        .count(history_count),
                                        
                                        .history_0(history_0), 
                                        .history_1(history_1), 
                                        .history_2(history_2),
                                        
                                        .history_a0(history_a0), 
                                        .history_a1(history_a1), 
                                        .history_a2(history_a2),

                                        .history_b0(history_b0), 
                                        .history_b1(history_b1), 
                                        .history_b2(history_b2),

                                        .history_op0(history_op0), 
                                        .history_op1(history_op1), 
                                        .history_op2(history_op2)                                                                                                                        
    );
    
    //OLED data from history renderer
    wire [15:0] oled_data_history;
    
    //select history calculation
    reg [1:0] history_select = 0;
    
    wire show_history = SW13;
    reg [15:0] calculator_pixel;

    
    //history OLED renderer
    history_renderer history_screen(.pixel_index(pixel_index),
                                    .count(history_count),
                                    .history_select(history_select),
                                    
                                    //first number
                                    .history_a0(history_a0),
                                    .history_a1(history_a1),
                                    .history_a2(history_a2),
                                    
                                    //second number
                                    .history_b0(history_b0),
                                    .history_b1(history_b1),
                                    .history_b2(history_b2),
                                    
                                    //operations 
                                    .history_op0(history_op0),
                                    .history_op1(history_op1),
                                    .history_op2(history_op2),
                                    
                                    //result 
                                    .history_0(history_0),
                                    .history_1(history_1),
                                    .history_2(history_2),
                                    
                                    .recall_error(1'b0),
                                    .pixel_data(oled_data_history));
                                    
    
    // Function to draw the digits
    function draw_digit;
        input [3:0] digit;
        input [6:0] x;
        input [5:0] y;
        input [6:0] xpos;
        input [5:0] ypos;
        
        reg A, B, C, D, E, F, G;
        
        begin
            
            A = 0; B = 0; C = 0; D = 0; E = 0; F = 0; G = 0;
            
            case(digit)
                0: begin
                    A = 1; B = 1; C = 1; D = 1; E = 1; F = 1;
                end
                
                1: begin
                    B = 1; C = 1;
                end
                
                2: begin
                    A = 1; B = 1; G = 1; E = 1; D = 1;
                end
                
                3: begin
                    A = 1; B = 1; C = 1; D = 1; G = 1;
                end
                
                4: begin
                    F = 1; G = 1; B = 1; C = 1;
                end   
                
                5: begin
                    A = 1; F = 1; G = 1; C = 1; D = 1;
                end 
                
                6: begin
                    A = 1; E = 1; G = 1; F = 1; D = 1; C = 1; 
                end
                
                7: begin
                    A = 1; B = 1; C = 1;
                end
                
                8: begin
                    A = 1; B = 1; C = 1; D = 1; E = 1; F = 1; G = 1;
                end
                
                9: begin
                    A = 1; B = 1; C = 1; D = 1; F = 1; G = 1;
                end
                
            endcase
            
            draw_digit =
                (A && x >= xpos+1  && x <= xpos+6 &&
                      y >= ypos    && y <= ypos+1) ||

                (B && x >= xpos+6  && x <= xpos+7 &&
                      y >= ypos    && y <= ypos+5) ||

                (C && x >= xpos+6  && x <= xpos+7 &&
                      y >= ypos+5  && y <= ypos+9) ||

                (D && x >= xpos+1  && x <= xpos+6 &&
                      y >= ypos+9  && y <= ypos+10) ||

                (E && x >= xpos+1  && x <= xpos+2 &&
                      y >= ypos+5  && y <= ypos+9) ||

                (F && x >= xpos+1  && x <= xpos+2 &&
                      y >= ypos    && y <= ypos+5) ||

                (G && x >= xpos+1  && x <= xpos+6 &&
                      y >= ypos+5  && y <= ypos+6) ||

                0;
            end
        endfunction
  
    wire signed [15:0] alternate_operand;
    
    localparam history_state = 1;
    localparam not_history_state = 0;
    reg alternate_state = not_history_state;
    
    always @(posedge CLOCK) begin
        
        // Check if we want to use results from earlier
        if (sw[10] || sw[9] || sw[8])
            alternate_state <= history_state;
        else
            alternate_state <= not_history_state;
    
        if (state != SHOW_RESULT)
            history_saved <= 0;
        else if (save_history)
            history_saved <= 1;

        // State 0: First number choice
        if (state == FIRST_NUMBER) begin
            if (btnC) begin
                state <= CHOOSE_OPERATION;
            end
        end
      
        // State 1: Operation choice
        else if (state == CHOOSE_OPERATION) begin
            if (btnU) begin
                operation <= ADD;
                operation_selected <= 1;
            end
            else if (btnD) begin
                operation <= SUB;
                operation_selected <= 1;
            end
            else if (btnL) begin
                operation <= MUL;
                operation_selected <= 1;
            end
            else if (btnR) begin
                operation <= DIV;
                operation_selected <= 1;
            end
                
            if (btnC && operation_selected)
                state <= SECOND_NUMBER;
        end
        
        // State 2: Second number choice and calculation
       else if (state == SECOND_NUMBER) begin
            if (btnC) begin                
                invalid_result <= invalid_now;
                result <= invalid_now ? 16'sd0 : calculated_result;

                state <= SHOW_RESULT;           
            end
        end
        
        // State 3: Show result
        else if (state == SHOW_RESULT) begin  
        
            if (SW14) begin          
                state <= FIRST_NUMBER;
                result <= 0;
                operation_selected <= 0;
                invalid_result <= 0;
            end
            
        end
        
    end
    
    reg [3:0] thousands;
    reg [3:0] hundreds;
    reg [3:0] tens;
    reg [3:0] ones;
    
    reg [7:0] display_A;
    reg [7:0] display_B;
    reg [15:0] display_result;
    reg [7:0] display_switch;
    
    assign  alternate_operand = (!sw[10] && !sw[9] && sw[8]) ? history_0 : 
                                (!sw[10] &&  sw[9]         ) ? history_1 : 
                                ( sw[10]                   ) ? history_2 : 16'sd0;
    
    always @(*) begin
        
        calculator_pixel = BLACK;
        an = 4'b1111;
        seg = 8'b11111111;
        
        if (alternate_state == history_state) begin
            an = 4'b1110;
        
            seg = (!sw[10] && !sw[9] && sw[8]) ? 8'b11111001 : 
                  (!sw[10] &&  sw[9]         ) ? 8'b10100101 : 
                  ( sw[10]                   ) ? 8'b10110000 : 8'b11111111;
        end
        
        if (operand_A < 0)
            display_A = -operand_A;
        else
            display_A = operand_A;
        
        if (operand_B < 0)
            display_B = -operand_B;
        else
            display_B = operand_B;
        
        if (result < 0)
            display_result = -result;
        else
            display_result = result;
            
        if (switch_value < 0)
            display_switch = -switch_value;
        else
            display_switch = switch_value;    
        
        hundreds = 0;
        tens = 0;
        ones = 0;
            
        // State 0: Write first number in orange
        if (state == FIRST_NUMBER) begin
                        
            //OPERAND A:
            // largest possible number: 127
            hundreds  = (display_switch / 100) % 10;
            tens      = (display_switch / 10) % 10;
            ones      = display_switch % 10;
            
            if (draw_digit(hundreds, x, y, 27, 5))
                calculator_pixel = ORANGE;
            else if (draw_digit(tens, x, y, 44, 5))
                calculator_pixel = ORANGE;
            else if (draw_digit(ones, x, y, 61, 5))
                calculator_pixel = ORANGE;
        end
        
        // State 1: Write number again in green + Write operator in orange
        
        else if (state == CHOOSE_OPERATION) begin
            //OPERAND A:
            
            hundreds  = (display_A / 100) % 10;
            tens      = (display_A / 10) % 10;
            ones      = display_A % 10;
            
            if (draw_digit(hundreds, x, y, 27, 5))
                calculator_pixel = GREEN;
            else if (draw_digit(tens, x, y, 44, 5))
                calculator_pixel = GREEN;
            else if (draw_digit(ones, x, y, 61, 5))
                calculator_pixel = GREEN;
        
            //OPERATION SIGN
            if (operation_selected) begin
                if (operation == ADD) begin
                    if (((x >= 79 && x <= 81) &&
                         (y >= 5  && y <= 15)) ||
                        ((x >= 75 && x <= 85) &&
                         (y >= 9  && y <= 11)))
                        calculator_pixel = GREEN;
                end
                
                else if (operation == SUB) begin
                    if ((x >= 75 && x <= 85) &&
                        (y >= 9 && y <= 11))    
                        calculator_pixel = GREEN;    
                end    
                   
                else if (operation == DIV) begin
                    if (((x >= 75 && x <= 85) &&
                         (y >= 9 && y <= 11)) ||
                        ((x >= 79 && x <= 81) &&
                         (y >= 5 && y <= 7)) ||
                        ((x >= 79 && x <= 81) &&
                         (y >= 13 && y <= 15)))
                        calculator_pixel = GREEN; 
                end
                  
                else if (operation == MUL) begin
                    if (((x - 79)*(x - 79) + (y - 9)*(y - 9)) <= 16)
                        calculator_pixel = GREEN;  
                end 
            end
        end
            
        else if (state == SECOND_NUMBER) begin
            
            // OPERAND B:
            // largest possible number: 127
            hundreds  = (display_switch / 100) % 10;
            tens      = (display_switch / 10) % 10;
            ones      = display_switch % 10;
            
            if (draw_digit(hundreds, x, y, 27, 20))
                calculator_pixel = ORANGE;
            else if (draw_digit(tens, x, y, 44, 20))
                calculator_pixel = ORANGE;
            else if (draw_digit(ones, x, y, 61, 20))
                calculator_pixel = ORANGE;
        end   
        
        else if (state == SHOW_RESULT) begin
            // OPERAND B
            
            hundreds = (display_B / 100) % 10;
            tens     = (display_B / 10) % 10;
            ones     = display_B % 10;
            
            if (draw_digit(hundreds, x, y, 27, 20))
                calculator_pixel = GREEN;
            else if (draw_digit(tens, x, y, 44, 20))
                calculator_pixel = GREEN;
            else if (draw_digit(ones, x, y, 61, 20))
                calculator_pixel = GREEN;
            
            // DRAW EQUAL SIGN
            if (((x >= 10 && x <= 20) &&
                 (y >= 44 && y <= 46)) ||
                ((x >= 10 && x <= 20) &&
                 (y >= 50 && y <= 52)))
                calculator_pixel = GREEN;  
            
            // RESULT   
            if (overflow) begin
                if (overflow_pixel == 16'hF800)
                    calculator_pixel = 16'hF800;
                end
            else begin 
            
            hundreds  = (display_result / 100) % 10;
            tens      = (display_result / 10) % 10;
            ones      = display_result % 10;
            
            if (draw_digit(hundreds, x, y, 27, 39))
                calculator_pixel = GREEN;
            else if (draw_digit(tens, x, y, 44, 39))
                calculator_pixel = GREEN;
            else if (draw_digit(ones, x, y, 61, 39))
                calculator_pixel = GREEN;
            end   
        end
    end
    
    //chose which OLED screen to display
    assign oled_data = show_history ? oled_data_history : calculator_pixel;
    
endmodule


